"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7859:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _select_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2622);
/* harmony import */ var _components_header_top_search__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4995);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_select_theme__WEBPACK_IMPORTED_MODULE_3__, _components_header_top_search__WEBPACK_IMPORTED_MODULE_4__]);
([_select_theme__WEBPACK_IMPORTED_MODULE_3__, _components_header_top_search__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const Burger = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>__webpack_require__.e(/* import() */ 805).then(__webpack_require__.bind(__webpack_require__, 8805)), {
    loadableGenerated: {
        modules: [
            "..\\components\\header\\header.tsx -> " + "./burger"
        ]
    }
});
function Header() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
        className: "sticky top-0 z-20 flex w-full h-[3rem] py-3 mx-auto border-b border-gray-200 backdrop-blur supports-backdrop-blur:bg-white/80 dark:border-gray-800 dark:supports-backdrop-blur:bg-gray-900/25",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex items-center justify-between px-4 w-full h-full mx-auto max-w-full lg:max-w-8xl",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Burger, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/docs",
                            className: "flex flex-row items-center font-bold text-gray-600 dark:text-white",
                            passHref: true,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/favicon.ico",
                                        alt: "favicon",
                                        style: {
                                            width: "25px",
                                            height: "25px",
                                            marginRight: "5px"
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                        children: "Tilil Technologies"
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex space-x-2 items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_header_top_search__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_select_theme__WEBPACK_IMPORTED_MODULE_3__/* .SelectTheme */ .n, {})
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8552:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* reexport safe */ _header__WEBPACK_IMPORTED_MODULE_0__.Z)
/* harmony export */ });
/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7859);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_header__WEBPACK_IMPORTED_MODULE_0__]);
_header__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2622:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ SelectTheme)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1185);
/* harmony import */ var _heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9476);
/* harmony import */ var _heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1162);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_themes__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _use_is_mounted__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8745);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_2__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const THEMES = {
    dark: {
        id: "dark",
        name: "Dark",
        icon: _heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_3__.MoonIcon
    },
    light: {
        id: "light",
        name: "Light",
        icon: _heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_3__.SunIcon
    },
    system: {
        id: "system",
        name: "System",
        icon: _heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_3__.ComputerDesktopIcon
    }
};
function SelectTheme() {
    const isMounted = (0,_use_is_mounted__WEBPACK_IMPORTED_MODULE_5__/* .useIsMounted */ .t)();
    const { theme , setTheme  } = (0,next_themes__WEBPACK_IMPORTED_MODULE_4__.useTheme)();
    const currentTheme = theme;
    if (!isMounted()) {
        return null;
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Listbox, {
        value: theme,
        onChange: setTheme,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "relative",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Listbox.Button, {
                    "aria-label": "Select theme",
                    className: " inline-flex items-center p-2.5 text-sm text-slate-600 hover:text-slate-700 dark:text-slate-300 dark:hover:text-slate-200 border rounded-lg bg-white hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-800 ease-in transition duration-150 focus-visible:ring-1 focus-visible:ring-blue-500 focus-visible:border-blue-500 focus-visible:outline-none dark:border-gray-800 dark:focus-visible:border-blue-500 ",
                    children: /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement(THEMES[currentTheme].icon, {
                        className: "w-4 h-4"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition, {
                    as: (react__WEBPACK_IMPORTED_MODULE_1___default().Fragment),
                    enter: "transition ease-out duration-100",
                    enterFrom: "opacity-0 translate-y-1",
                    enterTo: "opacity-100 translate-y-0",
                    leave: "transition ease-in duration-75",
                    leaveFrom: "opacity-100 translate-y-0",
                    leaveTo: "opacity-0 translate-y-1",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Listbox.Options, {
                        className: " fixed top-12 right-4 overflow-auto w-32 max-h-60 p-2 border border-gray-200 rounded-lg bg-white shadow-sm focus:outline-none dark:bg-gray-900 dark:border-gray-800 ",
                        children: Object.values(THEMES).map(({ id , name  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Listbox.Option, {
                                value: id,
                                className: ({ active  })=>`
                  flex
                  items-center
                  justify-between
                  px-4
                  py-2
                  text-sm
                  rounded-lg
                  cursor-pointer
                  select-none
                  duration-300
                  transition-colors
                  ${active ? "text-blue-700 dark:text-blue-600 dark:hover:text-blye-300 bg-blue-50 dark:bg-blue-800/10" : "text-slate-500 hover:text-slate-700 dark:text-slate-400 bg-white hover:bg-gray-50 dark:bg-transparent"}
                `,
                                children: name
                            }, id))
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4995:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1185);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_2__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function Search() {
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    onClick: ()=>setOpen(true),
                    className: " inline-flex items-center justify-center p-2 rounded-md border border-gray-300 text-gray-600 hover:text-gray-700 dark:text-white dark:border-gray-600 dark:hover:text-gray-400 ",
                    "aria-label": "Search",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        strokeWidth: 1.5,
                        stroke: "currentColor",
                        className: "w-6 h-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            d: "M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition, {
                show: open,
                as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Dialog, {
                    as: "div",
                    className: "fixed inset-0 z-50 overflow-y-auto",
                    onClose: setOpen,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "min-h-screen px-4 text-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Dialog.Overlay, {
                                className: "fixed inset-0 bg-black opacity-60"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "inline-block align-baseline max-w-md w-full p-3 my-4 overflow-hidden text-left align-middle transition-all transform bg-white shadow-xl rounded-lg",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Dialog.Title, {
                                        className: "text-lg font-medium mb-4",
                                        children: "Search"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "text",
                                                placeholder: "Search...",
                                                className: "w-full border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring focus:border-blue-300 dark:bg-gray-800 dark:border-gray-600 dark:text-white"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>setOpen(false),
                                                className: "ml-2 inline-flex items-center justify-center p-2 rounded-md border border-gray-300 text-gray-600 hover:text-gray-700 dark:text-grey-800 dark:border-gray-600 dark:hover:text-gray-400 ",
                                                "aria-label": "Close",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    className: "h-5 w-5",
                                                    viewBox: "0 0 20 20",
                                                    fill: "currentColor",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        fillRule: "evenodd",
                                                        d: "M2.293 3.293a1 1 0 011.414 0L10 8.586l6.293-6.293a1 1 0 111.414 1.414L11.414 10l6.293 6.293a1 1 0 11-1.414 1.414L10 11.414l-6.293 6.293a1 1 0 01-1.414-1.414L8.586 10 2.293 3.707a1 1 0 010-1.414z",
                                                        clipRule: "evenodd"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Search);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8745:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ useIsMounted)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useIsMounted() {
    const isMounted = react__WEBPACK_IMPORTED_MODULE_0___default().useRef(false);
    react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(()=>{
        isMounted.current = true;
        return ()=>{
            isMounted.current = false;
        };
    }, []);
    return react__WEBPACK_IMPORTED_MODULE_0___default().useCallback(()=>isMounted.current, []);
}


/***/ }),

/***/ 2778:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "z": () => (/* reexport */ skip_to_content)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/skip-to-content/skip-to-content.tsx

function SkipToContent() {
    return /*#__PURE__*/ jsx_runtime_.jsx("a", {
        href: "#overview",
        className: " sr-only focus:not-sr-only focus-visible:not-sr-only focus-visible:fixed focus-visible:top-6 focus-visible:left-6 focus-visible:z-30 focus-visible:py-4 focus-visible:px-4 focus-visible:text-slate-900 focus-visible:text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:rounded-lg focus-visible:bg-gray-100 ",
        children: "Skip to Content"
    });
}
/* harmony default export */ const skip_to_content = (SkipToContent);

;// CONCATENATED MODULE: ./src/components/skip-to-content/index.ts



/***/ }),

/***/ 3622:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "C": () => (/* reexport */ docs_layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
// EXTERNAL MODULE: external "@heroicons/react/20/solid"
var solid_ = __webpack_require__(9476);
;// CONCATENATED MODULE: ./src/config/sidebar.ts
const SIDEBAR = [
    {
        title: "Getting Started",
        children: [
            {
                title: "Overview",
                slug: "/docs"
            },
            {
                title: "Introduction",
                slug: "/docs/intro"
            },
            {
                title: "Getting Started Tutorial",
                slug: "/docs/getting-started"
            }, 
        ]
    },
    {
        title: "Bulk SMS Intergration",
        children: [
            {
                title: "Introduction",
                slug: "/docs/bulk-sms-api"
            },
            {
                title: "Delivery Codes",
                slug: "/docs/delivery-codes-and-descriptions"
            }, 
        ]
    },
    {
        title: "Short Code Intergration",
        children: [
            {
                title: "ShortCodes API",
                slug: "/docs/short-code-api"
            },
            {
                title: "Purchase and Pricing",
                slug: "/docs/purchasing-credit"
            },
            {
                title: "Subscription API",
                slug: "/docs/subscription-api"
            }, 
        ]
    }, 
];

;// CONCATENATED MODULE: ./src/config/config.ts
const GITHUB_EDIT_URL = ``;

;// CONCATENATED MODULE: ./src/config/index.ts



;// CONCATENATED MODULE: ./src/layouts/docs/components/aside/aside.tsx




function Aside() {
    let router = (0,router_namespaceObject.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx("aside", {
        id: "aside",
        className: " hidden z-10 fixed top-[64px] left-0 lg:inset-0 w-full h-full self-end bg-white backdrop-blur dark:supports-backdrop-blur:bg-gray-900/70 lg:sticky lg:block lg:w-64 lg:h-auto lg:bg-transparent lg:dark:bg-transparent ",
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            className: " h-[calc(100%-74px)] px-4 py-8 overflow-auto lg:sticky lg:top-20 lg:h-screen lg:block lg:pl-0 lg:pr-6 lg:py-12 dark:bg-transparent ",
            "aria-label": "Categories",
            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "space-y-6 pl-1",
                children: SIDEBAR.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                className: " block ml-3 mb-2 font-medium tracking-wide text-sm text-slate-900 dark:text-white ",
                                children: item.title
                            }),
                            Boolean(item.children?.length) && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                className: "space-y-1",
                                children: item.children?.map(({ title , slug  })=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: slug,
                                            passHref: true,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: slug,
                                                // eslint don't detect ternary value?
                                                // eslint-disable-next-line jsx-a11y/aria-proptypes
                                                "aria-current": `${router.pathname === slug ? "page" : "false"}`,
                                                className: " flex align-middle justify-between py-2 px-3 text-sm text-slate-500 dark:text-slate-400 dark:hover:text-blue-600 rounded outline-none focus-visible:ring-2 focus-visible:ring-blue-600 dark:focus-visible:ring-blue-600/50 hover:text-blue-600 aria-current-page:bg-blue-50 aria-current-page:text-blue-800 dark:aria-current-page:text-blue-500 dark:aria-current-page:bg-blue-600/10 ",
                                                children: title
                                            })
                                        })
                                    }, slug))
                            })
                        ]
                    }, item.title))
            })
        })
    });
}
/* harmony default export */ const aside = (Aside);

;// CONCATENATED MODULE: ./src/layouts/docs/components/aside/index.ts


;// CONCATENATED MODULE: ./src/layouts/docs/components/pagination/use-pagination.ts


function usePagination() {
    let router = (0,router_namespaceObject.useRouter)();
    let prev;
    let next;
    let links = SIDEBAR.reduce((prev, next)=>prev.concat(next.children), []);
    let makeURL = ({ title , slug  })=>{
        return {
            title,
            slug
        };
    };
    let getIndex = links.findIndex((item)=>{
        return router.pathname === item?.slug;
    });
    if (getIndex > 0) {
        prev = makeURL(links[getIndex - 1]);
    }
    if (getIndex !== -1 && getIndex < links.length - 1) {
        next = makeURL(links[getIndex + 1]);
    }
    return {
        prev,
        next
    };
}

;// CONCATENATED MODULE: ./src/layouts/docs/components/pagination/pagination.tsx




function Pagination() {
    let { prev , next  } = usePagination();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " flex gap-10 w-full ",
        children: [
            prev?.slug && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: prev.slug,
                passHref: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: prev.slug,
                    rel: "previous",
                    className: " flex justify-between items-center py-4 px-6 w-full text-left text-slate-600 dark:text-slate-100 border border-gray-200 hover:border-gray-200 dark:border-gray-100/5 bg-white hover:bg-gray-50 active:bg-gray-100 dark:active:bg-gray-800/20 dark:hover:bg-gray-800/10 dark:bg-gray-800/5 rounded-md ease-in duration-150 transition-colors focus:ring-2 focus:ring-gray-100 focus:border-gray-200 focus:outline-none dark:focus:ring-gray-600/10 ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(solid_.ChevronLeftIcon, {
                            className: " relative -left-3 w-5 h-5 "
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: " block text-xs text-slate-500 ",
                                    children: "previous"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: " block text-base text-slate-600 dark:text-slate-100 md:text-lg font-semibold line-clamp-1 ",
                                    children: prev.title
                                })
                            ]
                        })
                    ]
                })
            }),
            next?.slug && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: next.slug,
                passHref: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: next.slug,
                    rel: "next",
                    className: " flex justify-between items-center py-4 px-6 w-full text-left text-slate-600 dark:text-slate-100 border border-gray-200 hover:border-gray-200 dark:border-gray-100/5 bg-white hover:bg-gray-50 active:bg-gray-100 dark:active:bg-gray-800/20 dark:hover:bg-gray-800/10 dark:bg-gray-800/5 rounded-md ease-in duration-150 transition-colors focus:ring-2 focus:ring-gray-100 focus:border-gray-200 focus:outline-none dark:focus:ring-gray-600/10 ",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: " block text-xs text-slate-500 ",
                                    children: "next"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: " block text-base text-slate-600 dark:text-slate-100 lg:text-lg font-semibold line-clamp-1 ",
                                    children: next.title
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(solid_.ChevronRightIcon, {
                            className: " relative -right-3 w-8 h-8 "
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const pagination = (Pagination);

;// CONCATENATED MODULE: ./src/layouts/docs/components/pagination/index.ts


// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./src/layouts/docs/components/table-of-contents/table-of-contents.utils.ts
function collectHeadings(node, sections = []) {
    if (node && typeof node !== "string") {
        if (node?.name === "Heading") {
            sections.push({
                title: node.children[0],
                ...node.attributes
            });
        }
        if (node?.children) {
            for (const child of node.children){
                collectHeadings(child, sections);
            }
        }
    }
    return sections;
}

;// CONCATENATED MODULE: ./src/layouts/docs/components/table-of-contents/use-headings.ts

function useHeadings(contents) {
    let headings = collectHeadings(contents).filter((item)=>item.id && (item.level === 2 || item.level === 3));
    return {
        headings
    };
}

;// CONCATENATED MODULE: ./src/layouts/docs/components/table-of-contents/use-headings-observer.ts


function useHeadingsObserver() {
    let router = (0,router_namespaceObject.useRouter)();
    let listRef = external_react_default().useRef([]);
    let [currentId, setCurrentId] = external_react_default().useState("");
    external_react_default().useEffect(()=>{
        let headings = Array.from(document.querySelectorAll("article :is(h1,h2,h3)"));
        let callback = (elements)=>{
            listRef.current = elements.reduce((prev, el)=>{
                prev[el.target.id] = el;
                return prev;
            }, listRef.current);
            let visibles = [];
            Object.keys(listRef.current).forEach((key)=>{
                let el = listRef.current[key];
                if (el.isIntersecting) {
                    visibles.push(el.target.id);
                }
            });
            let getIndex = (id)=>{
                return headings.findIndex((heading)=>heading.id === id);
            };
            // If there is only one visible heading, this is our "active" heading
            if (visibles.length === 1) {
                setCurrentId(visibles[0]);
            // If there is more than one visible heading,
            // choose the one that is closest to the top of the page
            } else if (visibles.length > 1) {
                let sortedvisibles = visibles.sort((a, b)=>{
                    return getIndex(a) > getIndex(b) ? 1 : -1;
                });
                setCurrentId(sortedvisibles[0]);
            }
        };
        const observer = new IntersectionObserver(callback, {
            rootMargin: "-115px 0% 0%"
        });
        headings.forEach((element)=>observer.observe(element));
        router.events.on("routeChangeComplete", ()=>{
            headings.forEach((element)=>observer.observe(element));
        });
        return ()=>{
            router.events.off("routeChangeComplete", ()=>{
                observer.disconnect();
            });
        };
    }, [
        router
    ]);
    return {
        currentId
    };
}

;// CONCATENATED MODULE: ./src/layouts/docs/components/table-of-contents/table-of-contents.tsx




function TableOfContents(props) {
    let { contents  } = props;
    let { headings  } = useHeadings(contents);
    let { currentId  } = useHeadingsObserver();
    if (!Boolean(headings.length)) {
        return null;
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("aside", {
        className: "sticky inset-0 w-64 h-full",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " hidden sticky top-64 py-12 lg:block ",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: " block mb-4 text-sm text-slate-900 dark:text-white font-semibold tracking-wide ",
                    children: "On this page"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                    "aria-label": "Table of contents",
                    className: "overflow-x-hidden",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        children: headings.map(({ id , level , title  })=>{
                            return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `#${id}`,
                                    className: `
                    block
                    text-sm

                    ${level === 2 ? "py-2 font-medium" : "py-1 ml-4"}

                    ${currentId === id ? "text-blue-800 hover:text-blue-900" : "text-slate-500 dark:text-slate-300 hover:text-slate-600 dark:hover:text-slate-400"}
                  `,
                                    children: title
                                })
                            }, id);
                        })
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const table_of_contents = (/*#__PURE__*/external_react_default().memo(TableOfContents));

;// CONCATENATED MODULE: ./src/layouts/docs/components/table-of-contents/index.ts


;// CONCATENATED MODULE: ./src/layouts/docs/docs-layout.tsx








function DocsLayout(props) {
    let { markdoc , children  } = props;
    let router = (0,router_namespaceObject.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " relative px-4 w-full max-w-full mx-auto lg:flex xl:max-w-8xl ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(aside, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: " flex-auto py-12 w-full max-w-4xl lg:px-12 ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                        className: "mb-9",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                id: "overview",
                                className: " block mb-2 text-3xl text-slate-900 tracking-tight font-semibold dark:text-white ",
                                children: markdoc?.frontmatter.title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " block mt-0 text-base text-slate-500 dark:text-slate-400 ",
                                children: markdoc?.frontmatter.description
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                className: "block my-12 border-gray-200 dark:border-gray-200/10"
                            })
                        ]
                    }),
                    children,
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: `${GITHUB_EDIT_URL}${router.pathname === "/docs" ? `${router.pathname}/index` : router.pathname}.md`,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "flex items-center mb-6 cursor-pointer text-sm text-slate-600 dark:text-slate-400 hover:underline hover:text-slate-900",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(solid_.PencilSquareIcon, {
                                            className: "w-4 h-4 mr-2"
                                        }),
                                        "Edit this page on GitHub"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(pagination, {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(table_of_contents, {
                contents: markdoc?.content
            })
        ]
    });
}
/* harmony default export */ const docs_layout = (DocsLayout);

;// CONCATENATED MODULE: ./src/layouts/docs/index.ts



/***/ }),

/***/ 2957:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1162);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_themes__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_skip_to_content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2778);
/* harmony import */ var _components_header__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8552);
/* harmony import */ var _layouts_docs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3622);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_header__WEBPACK_IMPORTED_MODULE_5__]);
_components_header__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









function MyApp(props) {
    let { Component , pageProps , router  } = props;
    let isDocs = router.asPath.startsWith("/docs");
    let TITLE = pageProps.markdoc?.frontmatter.title;
    let DESCRIPTION = pageProps.markdoc?.frontmatter.description;
    let SITE = "https://" + process.env.VERCEL_URL;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: `${TITLE} -Tilil API Docs`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        charSet: "UTF-8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        httpEquiv: "X-UA-Compatible",
                        content: "IE=edge"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1, minimum-scale=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: DESCRIPTION
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:card",
                        content: "summary_large_image"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:site",
                        content: SITE
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:title",
                        content: TITLE
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:description",
                        content: DESCRIPTION
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:creator",
                        content: "@mverissimu"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:url",
                        content: SITE
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:type",
                        content: "article"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: TITLE
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: DESCRIPTION
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image",
                        content: `${process.env.VERCEL_URL ? SITE : ""}/api/og?title=${encodeURIComponent(TITLE)}&description=${encodeURIComponent(DESCRIPTION)}`
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_themes__WEBPACK_IMPORTED_MODULE_3__.ThemeProvider, {
                attribute: "class",
                disableTransitionOnChange: true,
                enableSystem: true,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skip_to_content__WEBPACK_IMPORTED_MODULE_4__/* .SkipToContent */ .z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_header__WEBPACK_IMPORTED_MODULE_5__/* .Header */ .h, {}),
                    isDocs ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layouts_docs__WEBPACK_IMPORTED_MODULE_6__/* .LayoutDocs */ .C, {
                        markdoc: pageProps.markdoc,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                            ...pageProps
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9476:
/***/ ((module) => {

module.exports = require("@heroicons/react/20/solid");

/***/ }),

/***/ 1089:
/***/ ((module) => {

module.exports = require("@heroicons/react/20/solid/index.js");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,152], () => (__webpack_exec__(2957)));
module.exports = __webpack_exports__;

})();