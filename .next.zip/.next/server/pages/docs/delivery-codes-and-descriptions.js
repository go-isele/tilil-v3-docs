"use strict";
(() => {
var exports = {};
exports.id = 28;
exports.ids = [28];
exports.modules = {

/***/ 8066:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ MarkdocComponent),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(626);
/* harmony import */ var _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5360);
/* harmony import */ var _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4266);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(436);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6113);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_nodes_index_ts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2785);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_yaml__WEBPACK_IMPORTED_MODULE_1__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__]);
([js_yaml__WEBPACK_IMPORTED_MODULE_1__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


// renderers is imported separately so Markdoc isn't sent to the client


/**
 * Schema is imported like this so end-user's code is compiled using build-in babel/webpack configs.
 * This enables typescript/ESnext support
 */ 


const functions = {};
const schema = {
    tags: (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__),
    nodes: (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_nodes_index_ts__WEBPACK_IMPORTED_MODULE_6__),
    functions: (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(functions),
    ...(0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__)
};
/**
 * Source will never change at runtime, so parse happens at the file root
 */ const source = "---\ntitle: Delivery Reports\n---\n\n## Getting Delivery Reports:\n\n1. **Offline (Pulling – Not recommended)**\n\n   This is a pull method where a client requests a delivery report from the system by specifying a message id in the request. The URL below will return a delivery report for message id 288369252.\n\n   - [https://api.tililtech.com/sms/v3/getdlr?api_key=%3cAPI_KEY%3e&messageId=288369252](https://api.tililtech.com/sms/v3/getdlr?api_key=%3cAPI_KEY%3e&messageId=288369252)\n\n## You Only Expect:\n\n1. `1009;No dlr`\n2. `288369252;Success;1;DeliveredToTerminal;2020-05-13 08:47:03;00:00:06`\n\nWhere:\n\n| Value                 | Name                 | Description                                                                                              |\n| --------------------- | -------------------- | -------------------------------------------------------------------------------------------------------- |\n| `288369252`           | Message Id           | Used when querying delivery reports                                                                      |\n| `Success`             | Request Status       | A status description for a successful request                                                            |\n| `1`                   | Delivery Status      | This can be used by developers for easy indexing of delivery statuses                                    |\n| `DeliveredToTerminal` | Delivery Description | Full description of the delivery status                                                                  |\n| `2020-05-13 08:47:03` | Delivery Date/Time   | When the message was actually delivered to the end user                                                  |\n| `00:00:06`            | TAT                  | The turn around time. From when a message was scheduled up to the time it was delivered to the end user. |\n\n## 2. Online (Recommended)\n\nThis is the recommended method of getting delivery reports. A partner specifies a delivery reports callback URL from the portal. All delivery reports sent through an API will be pushed to the URL automatically.\n\nBelow is a PHP sample that can be hosted by the client to receive delivery report notifications. Note that the client has to implement the Business Logic for example:\n\n- Updating a local sent message\n- Storing the delivery report for later processing\n- Generate a report or an alert for support monitoring\n\n```php\n<?php\n$data_json = file_get_contents('php://input');\n$data_array = json_decode($data_json);\n\nif (!$data_array) {\n    die(\"0;error;unsupported data type\");\n}\n\n$messageId = $data_array->messageId;\n$dlrTime = $data_array->dlrTime;\n$dlrStatus = $data_array->dlrStatus;\n$dlrDesc = $data_array->dlrDesc;\n$tat = $data_array->tat;\n$network = $data_array->network;\n\n// YOUR BUSINESS LOGIC\n\n// END YOUR LOGIC: if all goes well echo 'OK' otherwise echo 'FAILED' for the system to retry\necho \"OK;$messageId;$dlrDesc;$network\";\n?>\n```\n\n# Delivery Codes and Descriptions\n\n| Code | Delivery Status                  | Message General Status | Description                                                                                        |\n| ---- | -------------------------------- | ---------------------- | -------------------------------------------------------------------------------------------------- |\n| 1    | DeliveredToTerminal              | Delivered              | Message delivered to the end user's device                                                         |\n| 2    | MessageWaiting                   | Queued                 | Message forwarded to the operator but there is no delivery report                                  |\n| 3    | DeliveryImpossible               | Failed                 | The mobile operator is not able to deliver the message due to system errors. Rarely occurs         |\n| 4    | DeliveryNotificationNotSupported | Delivered              | Message delivered to the end user's device on the test bed environment                             |\n| 5    | DeliveredToNetwork               | NoReport               | Message forwarded to the operator but there is no delivery report                                  |\n| 6    | DeliveryUncertain                | NoReport               | Message forwarded to the operator but there is no delivery report after 24 hours                   |\n| 7    | Insufficient_Balance             | Failed                 | Message delivery failed because of insufficient balance                                            |\n| 8    | Invalid_Linkid                   | Failed                 | An on-demand message delivery failed because of an expired or invalid link id                      |\n| 9    | TeleserviceNotProvisioned        | Failed                 | End user device cannot receive GSM messages                                                        |\n| 10   | UserInBlacklist                  | Failed                 | End user has requested the mobile operator to stop all messages from the sender id to their number |\n| 11   | UserAbnormalState                | Failed                 | Subscriber mobile number may be blocked                                                            |\n| 12   | UserIsSuspended                  | Failed                 | Subscriber mobile number suspended due to fraud, etc.                                              |\n| 13   | NotSFCUser                       | Failed                 | End user not subscribed to a service                                                               |\n| 14   | UserNotSubscribed                | Failed                 | End user not subscribed to a service                                                               |\n| 15   | UserNotExist                     | Failed                 | Subscriber does not belong to the mobile operator                                                  |\n| 16   | AbsentSubscriber                 | Failed                 | Subscriber is out of network for over 24 hours since a message was sent                            |\n| 17   | NOT_DELIVERED                    | Failed                 | Same as DeliveryImpossible                                                                         |\n| 18   | DELIVERED                        | Delivered              | Message delivered to the end user's device                                                         |\n| 19   | ForwardedToNetwork               | NoReport               | Message forwarded to the operator but there is no delivery report                                  |\n| 20   | MessagePaused                    | Queued                 | Message paused by system user                                                                      |\n| 21   | MessageRejected                  | Failed                 | End user has opted out of messages from a sender id                                                |\n| 22   | Queued                           | Queued                 | Message has not been processed                                                                     |\n| 23   | InvalidMobile                    | Failed                 | (Not set)                                                                                          |\n| 24   | ReportNotHandled                 | Failed                 | (Not set)                                                                                          |\n";
const filepath = "\\docs\\delivery-codes-and-descriptions.md";
const ast = _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default().parse(source);
/**
 * Like the AST, frontmatter won't change at runtime, so it is loaded at file root.
 * This unblocks future features, such a per-page dataFetchingFunction.
 */ const frontmatter = ast.attributes.frontmatter ? js_yaml__WEBPACK_IMPORTED_MODULE_1__["default"].load(ast.attributes.frontmatter) : {};
const { components , ...rest } = (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .getSchema */ .J)(schema);
async function getStaticProps(context) {
    const partials = {};
    // Ensure Node.transformChildren is available
    Object.keys(partials).forEach((key)=>{
        partials[key] = _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default().parse(partials[key]);
    });
    const cfg = {
        ...rest,
        variables: {
            ...rest ? rest.variables : {},
            // user can't override this namespace
            markdoc: {
                frontmatter
            },
            // Allows users to eject from Markdoc rendering and pass in dynamic variables via getServerSideProps
            ...context.variables || {}
        },
        partials,
        source
    };
    /**
   * transform must be called in dataFetchingFunction to support server-side rendering while
   * accessing variables on the server
   */ const content = await _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default().transform(ast, cfg);
    return {
        // Removes undefined
        props: JSON.parse(JSON.stringify({
            markdoc: {
                content,
                frontmatter,
                file: {
                    path: filepath
                }
            }
        }))
    };
}
function MarkdocComponent(props) {
    // Only execute HMR code in development
    return _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2__.renderers.react(props.markdoc.content, (react__WEBPACK_IMPORTED_MODULE_0___default()), {
        components: {
            ...components,
            // Allows users to override default components at runtime, via their _app
            ...props.components
        }
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9476:
/***/ ((module) => {

module.exports = require("@heroicons/react/20/solid");

/***/ }),

/***/ 2135:
/***/ ((module) => {

module.exports = require("@heroicons/react/24/outline");

/***/ }),

/***/ 5360:
/***/ ((module) => {

module.exports = require("@markdoc/markdoc");

/***/ }),

/***/ 861:
/***/ ((module) => {

module.exports = require("parse-numeric-range");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("prism-react-renderer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4856:
/***/ ((module) => {

module.exports = require("react-use-clipboard");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 626:
/***/ ((module) => {

module.exports = import("js-yaml");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [266,436], () => (__webpack_exec__(8066)));
module.exports = __webpack_exports__;

})();