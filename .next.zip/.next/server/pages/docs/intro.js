"use strict";
(() => {
var exports = {};
exports.id = 855;
exports.ids = [855];
exports.modules = {

/***/ 9834:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ MarkdocComponent),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(626);
/* harmony import */ var _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5360);
/* harmony import */ var _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4266);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(436);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6113);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_nodes_index_ts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2785);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_yaml__WEBPACK_IMPORTED_MODULE_1__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__]);
([js_yaml__WEBPACK_IMPORTED_MODULE_1__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


// renderers is imported separately so Markdoc isn't sent to the client


/**
 * Schema is imported like this so end-user's code is compiled using build-in babel/webpack configs.
 * This enables typescript/ESnext support
 */ 


const functions = {};
const schema = {
    tags: (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__),
    nodes: (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_nodes_index_ts__WEBPACK_IMPORTED_MODULE_6__),
    functions: (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(functions),
    ...(0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__)
};
/**
 * Source will never change at runtime, so parse happens at the file root
 */ const source = "---\ntitle: Bulk SMS API Development Strategy\n---\n\n# API Development Strategy by Tilil Tech\n\nWelcome to Tilil Tech's Bulk SMS API Development Strategy guide! This document outlines our approach to developing and managing major version upgrades for our Bulk SMS API.\n\nThis strategy is discussed in more detail in our [Future Flags][future-flags-blog-post] blog post. Check it out for further information!\n\n## Goals\n\nAt Tilil Tech, our goals for major Bulk SMS API releases are:\n\n- Enable developers to opt-into SemVer-major features individually as they are released.\n- Facilitate easy adoption of new features without the need to adopt them all at once during a new major version.\n";
const filepath = "\\docs\\intro.md";
const ast = _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default().parse(source);
/**
 * Like the AST, frontmatter won't change at runtime, so it is loaded at file root.
 * This unblocks future features, such a per-page dataFetchingFunction.
 */ const frontmatter = ast.attributes.frontmatter ? js_yaml__WEBPACK_IMPORTED_MODULE_1__["default"].load(ast.attributes.frontmatter) : {};
const { components , ...rest } = (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .getSchema */ .J)(schema);
async function getStaticProps(context) {
    const partials = {};
    // Ensure Node.transformChildren is available
    Object.keys(partials).forEach((key)=>{
        partials[key] = _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default().parse(partials[key]);
    });
    const cfg = {
        ...rest,
        variables: {
            ...rest ? rest.variables : {},
            // user can't override this namespace
            markdoc: {
                frontmatter
            },
            // Allows users to eject from Markdoc rendering and pass in dynamic variables via getServerSideProps
            ...context.variables || {}
        },
        partials,
        source
    };
    /**
   * transform must be called in dataFetchingFunction to support server-side rendering while
   * accessing variables on the server
   */ const content = await _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default().transform(ast, cfg);
    return {
        // Removes undefined
        props: JSON.parse(JSON.stringify({
            markdoc: {
                content,
                frontmatter,
                file: {
                    path: filepath
                }
            }
        }))
    };
}
function MarkdocComponent(props) {
    // Only execute HMR code in development
    return _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2__.renderers.react(props.markdoc.content, (react__WEBPACK_IMPORTED_MODULE_0___default()), {
        components: {
            ...components,
            // Allows users to override default components at runtime, via their _app
            ...props.components
        }
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9476:
/***/ ((module) => {

module.exports = require("@heroicons/react/20/solid");

/***/ }),

/***/ 2135:
/***/ ((module) => {

module.exports = require("@heroicons/react/24/outline");

/***/ }),

/***/ 5360:
/***/ ((module) => {

module.exports = require("@markdoc/markdoc");

/***/ }),

/***/ 861:
/***/ ((module) => {

module.exports = require("parse-numeric-range");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("prism-react-renderer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4856:
/***/ ((module) => {

module.exports = require("react-use-clipboard");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 626:
/***/ ((module) => {

module.exports = import("js-yaml");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [266,436], () => (__webpack_exec__(9834)));
module.exports = __webpack_exports__;

})();