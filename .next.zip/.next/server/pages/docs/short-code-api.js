"use strict";
(() => {
var exports = {};
exports.id = 419;
exports.ids = [419];
exports.modules = {

/***/ 5959:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ MarkdocComponent),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(626);
/* harmony import */ var _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5360);
/* harmony import */ var _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4266);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(436);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6113);
/* harmony import */ var C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_nodes_index_ts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2785);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_yaml__WEBPACK_IMPORTED_MODULE_1__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__]);
([js_yaml__WEBPACK_IMPORTED_MODULE_1__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__, C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


// renderers is imported separately so Markdoc isn't sent to the client


/**
 * Schema is imported like this so end-user's code is compiled using build-in babel/webpack configs.
 * This enables typescript/ESnext support
 */ 


const functions = {};
const schema = {
    tags: (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_tags_index_ts__WEBPACK_IMPORTED_MODULE_5__),
    nodes: (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_nodes_index_ts__WEBPACK_IMPORTED_MODULE_6__),
    functions: (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(functions),
    ...(0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .defaultObject */ .w)(C_Users_user_Desktop_Projects_web_tilil_docs_v3_markdoc_config_ts__WEBPACK_IMPORTED_MODULE_4__)
};
/**
 * Source will never change at runtime, so parse happens at the file root
 */ const source = '---\ntitle: Short Code Messaging\n---\n\n## 1. Receiving Inbound Messages\n\nThe client will provide an endpoint that accepts the following JSON data through a POST request. In cases where a client wants the data pushed over a secure connection such as over SSL, the client will provide the necessary certificates to be configured in our application.\n\n```json\n{\n  "api_token": "944a73412bed1240b5a2afa381a928a6",\n  "timestamp": "20180217065028",\n  "mobile": "254726770792",\n  "message": "Test inbox",\n  "shortcode": "70700",\n  "inbox_id": "4448236",\n  "service_id": "32",\n  "network_name": "Safaricom",\n  "link_id": "763723672367236526261"\n}\n```\n\n### Where:\n\n| Variable       | Type   | Description                                                                                                                                                            | Example                            |\n| -------------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------- |\n| `api_token`    | String | The token supplied by a partner for our service request authentication purposes. This can be an encrypted value of their username, server IP, timestamp, and password. | `944a73412bed1240b5a2afa381a928a6` |\n| `timestamp`    | String | Timestamp in the format YmdHis to be used in password decryption.                                                                                                      | `20180217065028`                   |\n| `mobile`       | String | The user mobile number that should receive the payment. All mobile numbers are validated before a request is accepted.                                                 | `254726770792`                     |\n| `message`      | String | The message as received from the end user.                                                                                                                             | `Test inbox`                       |\n| `shortcode`    | String | The short code associated with the service.                                                                                                                            | `70700`                            |\n| `inbox_id`     | Int    | A unique identifier of the message.                                                                                                                                    | `4448236`                          |\n| `service_id`   | Int    | The service identifier for the service.                                                                                                                                | `32`                               |\n| `network_name` | String | A network identifier e.g Safaricom, Airtel, Yu, Equitel & Telkom.                                                                                                      | `Safaricom`                        |\n| `link_id`      | String | Received for On-Demand shortcode messages. This should be used when sending out replies.                                                                               | `763723672367236526261`            |\n\n## 2. Sending Short Code Messages\n\nThis is the same as sending a bulk message. The only difference is that a `service_id` will be added to this request. See example JSON below.\n\n- On successful reception of an inbound message, the client should reply (echo back) with the following JSON string:\n\n```json\n{\n  "result_code": 1,\n  "result_desc": "OK",\n  "result_message": "Thank you for your message."\n}\n```\n\n### Where:\n\n| Variable         | Type   | Description                                                                                                                                                  | Example                      |\n| ---------------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------- |\n| `request_code`   | Int    | This is a status of the pushed message: 1 – Success; 0 – Failed. A message might fail to be received on the client’s side due to internal server errors etc. | `1` or `0`                   |\n| `request_desc`   | String | This is a brief description of the request. OK for successful reception; FAILED for a failed request.                                                        | `OK` or `FAILED`             |\n| `result_message` | String | This is a message our system should send back to the end user. Leave this empty to process a user request and reply back later through the sendSms API.      | `Thank you for your message` |\n\n# SMS API\n\n### Where:\n\n| Variable      | Type   | Description                                                                                       | Example                                                |\n| ------------- | ------ | ------------------------------------------------------------------------------------------------- | ------------------------------------------------------ |\n| `api_key`     | Int    | The authentication string provided to the customer.                                               | `qw566wqtwgqyw65wq`                                    |\n| `sender_name` | String | The origination alphanumeric or numeric code.                                                     | `22915`                                                |\n| `message`     | String | The message our system should send to the end user. The message can be up to 920 characters long. | `Click on the following link to download your content` |\n| `mobile`      | String | Mobile number to receive the MT message.                                                          | `0708400000`                                           |\n| `service_id`  | Int    | An identifier of the service allocated to the customer.                                           | `44`                                                   |\n| `link_id`     | Long   | Used for On-Demand messages. Leave empty for subscription services.                               | `12345678987654321`                                    |\n\n---\n\nThis data is posted to the following endpoint:\n\nsendSms endpoint: [https://api.tililsms.com/sms/v3/sendsms](https://api.tililsms.com/sms/v3/sendsms)\n\n---\n\n### Success Response Packet:\n\n```json\n{\n  "status_code": "1000",\n  "status_desc": "Success",\n  "message_id": "sms.5ed0e9e9619937.17151728",\n  "mobile_number": "254708400000",\n  "network_name": "Safaricom",\n  "message_cost": "1",\n  "credit_balance": "-1"\n}\n```\n\n### Failed Response Packet:\n\n```json\n{\n  "status_code": "1003",\n  "status_desc": "Invalid mobile number 26770792",\n  "message_id": "0",\n  "mobile_number": "0",\n  "network_name": "Not set",\n  "message_cost": "0.00",\n  "credit_balance": ""\n}\n```\n\n## 3. Receiving (Un)Subscription Requests\n\nThe client will register an endpoint with us that accepts JSON post requests. See a request sample below:\n\n```json\n{\n  "api_token": "23627367236232ghgge23g22gh2gh2",\n  "network_name": "Safaricom",\n  "shortcode": "22915",\n  "service_id": "44",\n  "mobile": "254708400000",\n  "update_type": "activation",\n  "keyword": "GAME",\n  "subscriber_ref": "12345",\n  "timestamp": "20200528124756"\n}\n```\n\n# Subscription Request Variables\n\n### Where:\n\n| Variable         | Type   | Description                                                                                                                                                            | Example                        |\n| ---------------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------ |\n| `api_token`      | String | The token supplied by a partner for our service request authentication purposes. This can be an encrypted value of their username, server IP, timestamp, and password. | `2tyy23ty43y434hj3h43u4u3u4u`  |\n| `timestamp`      | String | Timestamp in the format YmdHis that shows when the customer subscribed or unsubscribed.                                                                                | `20200528124756`               |\n| `mobile`         | String | The user mobile number that should receive the payment. All mobile numbers are validated before a request is accepted.                                                 | `254708400000`                 |\n| `update_type`    | String | This indicates the customer request: activation for a customer subscribing and deactivation for a customer unsubscribing.                                              | `activation` or `deactivation` |\n| `shortcode`      | String | The short code associated with the service.                                                                                                                            | `22915`                        |\n| `keyword`        | String | The exact keyword a user used when subscribing to the service.                                                                                                         | `GAME`                         |\n| `subscriber_ref` | Int    | A unique identifier of the customer in our services.                                                                                                                   | `12345`                        |\n| `service_id`     | Int    | The service identifier for the service.                                                                                                                                | `44`                           |\n| `network_name`   | String | A network of the customer e.g Safaricom, Airtel, Yu, Equitel & Telkom.                                                                                                 | `Safaricom`                    |\n\n# (Un)Subscription Response\n\nOn successful reception of the (un)subscription request, the client should reply (echo back) with the following JSON string:\n\n### Where:\n\n| Variable         | Type   | Description                                                                                                                                                            | Example                                    |\n| ---------------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------ |\n| `request_code`   | Int    | This is a status of the request to enable our system mark it as done: 1 – Success; 0 – Failed. A Failed request will be retried automatically after 3 minutes 3 times. | `1` or `0`                                 |\n| `request_desc`   | String | This is a brief description of the request. OK for successful reception; FAILED for a failed request.                                                                  | `OK` or `FAILED`                           |\n| `result_message` | String | This is a message our system should send back to the customer. Leave this empty to process a user request and reply back later through the sendSms API.                | `Thank you for subscribing to our service` |\n\nExample JSON string:\n\n```json\n{\n  "result_code": 1,\n  "result_desc": "OK",\n  "result_message": "Thank you for subscribing to our service."\n}\n```\n';
const filepath = "\\docs\\short-code-api.md";
const ast = _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default().parse(source);
/**
 * Like the AST, frontmatter won't change at runtime, so it is loaded at file root.
 * This unblocks future features, such a per-page dataFetchingFunction.
 */ const frontmatter = ast.attributes.frontmatter ? js_yaml__WEBPACK_IMPORTED_MODULE_1__["default"].load(ast.attributes.frontmatter) : {};
const { components , ...rest } = (0,C_Users_user_Desktop_Projects_web_tilil_docs_v3_node_modules_markdoc_next_js_src_runtime_js__WEBPACK_IMPORTED_MODULE_3__/* .getSchema */ .J)(schema);
async function getStaticProps(context) {
    const partials = {};
    // Ensure Node.transformChildren is available
    Object.keys(partials).forEach((key)=>{
        partials[key] = _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default().parse(partials[key]);
    });
    const cfg = {
        ...rest,
        variables: {
            ...rest ? rest.variables : {},
            // user can't override this namespace
            markdoc: {
                frontmatter
            },
            // Allows users to eject from Markdoc rendering and pass in dynamic variables via getServerSideProps
            ...context.variables || {}
        },
        partials,
        source
    };
    /**
   * transform must be called in dataFetchingFunction to support server-side rendering while
   * accessing variables on the server
   */ const content = await _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2___default().transform(ast, cfg);
    return {
        // Removes undefined
        props: JSON.parse(JSON.stringify({
            markdoc: {
                content,
                frontmatter,
                file: {
                    path: filepath
                }
            }
        }))
    };
}
function MarkdocComponent(props) {
    // Only execute HMR code in development
    return _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_2__.renderers.react(props.markdoc.content, (react__WEBPACK_IMPORTED_MODULE_0___default()), {
        components: {
            ...components,
            // Allows users to override default components at runtime, via their _app
            ...props.components
        }
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9476:
/***/ ((module) => {

module.exports = require("@heroicons/react/20/solid");

/***/ }),

/***/ 2135:
/***/ ((module) => {

module.exports = require("@heroicons/react/24/outline");

/***/ }),

/***/ 5360:
/***/ ((module) => {

module.exports = require("@markdoc/markdoc");

/***/ }),

/***/ 861:
/***/ ((module) => {

module.exports = require("parse-numeric-range");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("prism-react-renderer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4856:
/***/ ((module) => {

module.exports = require("react-use-clipboard");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 626:
/***/ ((module) => {

module.exports = import("js-yaml");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [266,436], () => (__webpack_exec__(5959)));
module.exports = __webpack_exports__;

})();