"use strict";
exports.id = 436;
exports.ids = [436];
exports.modules = {

/***/ 436:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _tags__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6113);
/* harmony import */ var _nodes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2785);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tags__WEBPACK_IMPORTED_MODULE_0__]);
_tags__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// eslint-disable-next-line import/no-anonymous-default-export
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    tags: {
        callout: _tags__WEBPACK_IMPORTED_MODULE_0__.callout,
        markdoc: _tags__WEBPACK_IMPORTED_MODULE_0__.markdoc,
        "tab-group": _tags__WEBPACK_IMPORTED_MODULE_0__.tabGroup,
        tab: _tags__WEBPACK_IMPORTED_MODULE_0__.tab,
        "tab-list": _tags__WEBPACK_IMPORTED_MODULE_0__.tabList,
        "tab-panels": _tags__WEBPACK_IMPORTED_MODULE_0__.tabPanels,
        "tab-panel": _tags__WEBPACK_IMPORTED_MODULE_0__.tabPanel,
        disclosure: _tags__WEBPACK_IMPORTED_MODULE_0__.disclosure,
        "disclosure-button": _tags__WEBPACK_IMPORTED_MODULE_0__.disclosureButton,
        "disclosure-panel": _tags__WEBPACK_IMPORTED_MODULE_0__.disclosurePanel
    },
    nodes: _nodes__WEBPACK_IMPORTED_MODULE_1__
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2785:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "fence": () => (/* reexport */ nodes_fence),
  "heading": () => (/* reexport */ nodes_heading)
});

// EXTERNAL MODULE: ./src/components/fence/index.ts + 2 modules
var fence = __webpack_require__(7016);
;// CONCATENATED MODULE: ./markdoc/nodes/fence.ts

const fence_fence = {
    render: fence/* Fence */.Q,
    attributes: {
        children: {
            type: String,
            required: true
        },
        highlight: {
            type: String
        },
        language: {
            type: String,
            required: true
        }
    }
};
/* harmony default export */ const nodes_fence = (fence_fence);

// EXTERNAL MODULE: external "@markdoc/markdoc"
var markdoc_ = __webpack_require__(5360);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@heroicons/react/20/solid"
var solid_ = __webpack_require__(9476);
;// CONCATENATED MODULE: ./src/components/heading/heading.tsx



function Heading(props) {
    let { id , level =1 , children  } = props;
    let Component = /*#__PURE__*/ external_react_.createElement(`h${level}`, {
        id
    }, children);
    if (level > 1) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " relative -ml-4 pl-4 group ",
            children: [
                Component,
                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: `#${id}`,
                    "aria-label": "anchor",
                    className: " absolute top-1 -ml-10 flex items-center justify-center w-4 h-4 text-slate-400 ring-1 ring-slate-900/5 bg-white rounded-md outline-none opacity-0 group-hover:opacity-100 focus:ring-2 focus:ring-blue-100 hover:ring-slate-900/10 hover:shadow hover:text-slate-700 dark:text-white dark:bg-gray-600/10 dark:focus:ring-blue-600/50 ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(solid_.HashtagIcon, {
                        width: 12,
                        height: 12
                    })
                })
            ]
        });
    }
    return Component;
}
/* harmony default export */ const heading = (Heading);

;// CONCATENATED MODULE: ./src/components/heading/index.ts


;// CONCATENATED MODULE: ./markdoc/nodes/heading.ts


function generateID(children, attributes) {
    if (attributes?.id && typeof attributes.id === "string") {
        return attributes.id;
    }
    return children?.filter((child)=>typeof child === "string").join(" ").replace(/[?]/g, "").replace(/\s+/g, "-").toLowerCase();
}
const heading_heading = {
    render: heading,
    children: [
        "inline"
    ],
    attributes: {
        id: {
            type: String
        },
        level: {
            type: Number,
            required: true,
            default: 1
        }
    },
    transform (node, config) {
        const attributes = node.transformAttributes(config);
        const children = node.transformChildren(config);
        const id = generateID(children, attributes);
        return new markdoc_.Tag(this.render, {
            ...attributes,
            id
        }, children);
    }
};
/* harmony default export */ const nodes_heading = (heading_heading);

;// CONCATENATED MODULE: ./markdoc/nodes/index.ts




/***/ }),

/***/ 3746:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ tags_callout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@heroicons/react/20/solid"
var solid_ = __webpack_require__(9476);
;// CONCATENATED MODULE: ./src/components/callout/callout.tsx



const APPEARANCES = {
    caution: {
        title: "caution",
        icon: solid_.ExclamationTriangleIcon,
        className: "text-yellow-700 bg-yellow-50 dark:text-yellow-400 dark:bg-yellow-600/10"
    },
    danger: {
        title: "danger",
        icon: solid_.FireIcon,
        className: "text-red-700 bg-red-50 dark:text-red-400 dark:bg-red-600/10"
    },
    info: {
        title: "info",
        icon: solid_.ExclamationCircleIcon,
        className: "text-blue-700 bg-blue-50 dark:text-blue-400 dark:bg-blue-600/10"
    },
    tip: {
        title: "tip",
        icon: solid_.LightBulbIcon,
        className: "text-green-700 bg-green-50 dark:text-green-400 dark:bg-green-600/10"
    },
    note: {
        title: "note",
        icon: solid_.InformationCircleIcon,
        className: "text-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-600/10"
    }
};
function Callout(props) {
    let { appearance ="note" , title , children , ...rest } = props;
    let element = APPEARANCES[appearance];
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `
        p-4
        mb-6

        border
        border-l-4
        border-l-current

        dark:border-t-0
        dark:border-b-0
        dark:border-r-0

        rounded-md
        text-sm

        not-prose

        ${`[&>div>p>a]:underline`}
        ${element.className}
      `,
        ...rest,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " flex flex-col ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: " flex items-center uppercase font-bold ",
                    children: [
                        /*#__PURE__*/ external_react_default().createElement(element.icon, {
                            className: "w-6 h-6 mr-2"
                        }),
                        title ?? element.title
                    ]
                }),
                external_react_default().Children.toArray(children).map((child, index)=>/*#__PURE__*/ external_react_default().cloneElement(child, {
                        key: index,
                        className: "mt-1 text-slate-700 dark:text-slate-300"
                    }))
            ]
        })
    });
}
/* harmony default export */ const callout = (Callout);

;// CONCATENATED MODULE: ./src/components/callout/index.ts


;// CONCATENATED MODULE: ./markdoc/tags/callout.ts

const callout_callout = {
    render: callout,
    children: [
        "paragraph",
        "tag",
        "list"
    ],
    attributes: {
        appearance: {
            type: String,
            default: "note",
            matches: [
                "caution",
                "danger",
                "info",
                "note",
                "tip"
            ],
            errorLevel: "critical"
        },
        title: {
            type: String
        }
    }
};
/* harmony default export */ const tags_callout = (callout_callout);


/***/ }),

/***/ 8287:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xg": () => (/* binding */ disclosurePanel),
/* harmony export */   "cz": () => (/* binding */ disclosure),
/* harmony export */   "f0": () => (/* binding */ disclosureButton)
/* harmony export */ });
/* harmony import */ var _components_disclosure__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7163);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_disclosure__WEBPACK_IMPORTED_MODULE_0__]);
_components_disclosure__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const disclosure = {
    render: _components_disclosure__WEBPACK_IMPORTED_MODULE_0__/* .Disclosure */ .pJ,
    attributes: {
        defaultOpen: {
            type: Boolean
        }
    }
};
const disclosureButton = {
    render: _components_disclosure__WEBPACK_IMPORTED_MODULE_0__/* .DisclosureButton */ .lG,
    selfClosing: true,
    attributes: {
        label: {
            type: String
        }
    }
};
const disclosurePanel = {
    render: _components_disclosure__WEBPACK_IMPORTED_MODULE_0__/* .DisclosurePanel */ .V2
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6113:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "callout": () => (/* reexport safe */ _callout__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "disclosure": () => (/* reexport safe */ _disclosure__WEBPACK_IMPORTED_MODULE_3__.cz),
/* harmony export */   "disclosureButton": () => (/* reexport safe */ _disclosure__WEBPACK_IMPORTED_MODULE_3__.f0),
/* harmony export */   "disclosurePanel": () => (/* reexport safe */ _disclosure__WEBPACK_IMPORTED_MODULE_3__.Xg),
/* harmony export */   "markdoc": () => (/* reexport safe */ _markdoc__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "tab": () => (/* reexport safe */ _tabs__WEBPACK_IMPORTED_MODULE_0__.n2),
/* harmony export */   "tabGroup": () => (/* reexport safe */ _tabs__WEBPACK_IMPORTED_MODULE_0__.ug),
/* harmony export */   "tabList": () => (/* reexport safe */ _tabs__WEBPACK_IMPORTED_MODULE_0__.SN),
/* harmony export */   "tabPanel": () => (/* reexport safe */ _tabs__WEBPACK_IMPORTED_MODULE_0__.Xk),
/* harmony export */   "tabPanels": () => (/* reexport safe */ _tabs__WEBPACK_IMPORTED_MODULE_0__.zZ)
/* harmony export */ });
/* harmony import */ var _tabs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7048);
/* harmony import */ var _callout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3746);
/* harmony import */ var _markdoc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4667);
/* harmony import */ var _disclosure__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8287);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tabs__WEBPACK_IMPORTED_MODULE_0__, _disclosure__WEBPACK_IMPORTED_MODULE_3__]);
([_tabs__WEBPACK_IMPORTED_MODULE_0__, _disclosure__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5360);
/* harmony import */ var _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_markdoc_markdoc__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_fence__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7016);


const markdoc = {
    render: _components_fence__WEBPACK_IMPORTED_MODULE_1__/* .Fence */ .Q,
    attributes: {},
    transform (node, config) {
        const attributes = node.transformAttributes(config);
        const { content , language  } = node.children[0].attributes;
        return new _markdoc_markdoc__WEBPACK_IMPORTED_MODULE_0__.Tag(this.render, {
            ...attributes,
            language
        }, [
            content
        ]);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (markdoc);


/***/ }),

/***/ 7048:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SN": () => (/* binding */ tabList),
/* harmony export */   "Xk": () => (/* binding */ tabPanel),
/* harmony export */   "n2": () => (/* binding */ tab),
/* harmony export */   "ug": () => (/* binding */ tabGroup),
/* harmony export */   "zZ": () => (/* binding */ tabPanels)
/* harmony export */ });
/* harmony import */ var _components_tabs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1557);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_tabs__WEBPACK_IMPORTED_MODULE_0__]);
_components_tabs__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const tabGroup = {
    render: _components_tabs__WEBPACK_IMPORTED_MODULE_0__/* .TabGroup */ .v0,
    attributes: {
        defaultIndex: {
            type: Number
        }
    }
};
const tabList = {
    render: _components_tabs__WEBPACK_IMPORTED_MODULE_0__/* .TabList */ .td,
    attributes: {
        "aria-label": {
            type: String
        }
    }
};
const tab = {
    render: _components_tabs__WEBPACK_IMPORTED_MODULE_0__/* .Tab */ .OK,
    selfClosing: true,
    attributes: {
        disabled: {
            type: Boolean
        },
        label: {
            type: String
        },
        children: {
            type: String
        }
    }
};
const tabPanels = {
    render: _components_tabs__WEBPACK_IMPORTED_MODULE_0__/* .TabPanels */ .nP
};
const tabPanel = {
    render: _components_tabs__WEBPACK_IMPORTED_MODULE_0__/* .TabPanel */ .x4,
    attributes: {
        language: {
            type: String
        }
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5831:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1185);
/* harmony import */ var _heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9476);
/* harmony import */ var _heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8444);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_2__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function Disclosure(props) {
    let { label , children , ...rest } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Disclosure.Button, {
        className: " flex items-center w-full px-1.5 py-2 text-sm text-slate-900 font-semibold rounded-lg ease-in duration-100 transition-colors outline-none focus-visible:ring-2 focus-visible:ring-blue-600 dark:focus-visible:ring-blue-600/10 dark:text-white backdrop-blur hover:bg-gray-100 hover:dark:bg-gray-400/10 [&>p]:m-0 ",
        ...rest,
        children: ({ open  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_3__.ChevronRightIcon, {
                        className: (0,_utils_classnames__WEBPACK_IMPORTED_MODULE_4__.cn)("w-5 h-5 ease-in duration-150", open && "rotate-90")
                    }),
                    label ?? children
                ]
            })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Disclosure);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4826:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function Disclosure(props) {
    let { children  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Disclosure.Panel, {
        children: children
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Disclosure);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8448:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function Disclosure(props) {
    let { children  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "mb-6",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Disclosure, {
            children: children
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Disclosure);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7163:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V2": () => (/* reexport safe */ _disclosure_panel__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "lG": () => (/* reexport safe */ _disclosure_button__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "pJ": () => (/* reexport safe */ _disclosure__WEBPACK_IMPORTED_MODULE_0__.Z)
/* harmony export */ });
/* harmony import */ var _disclosure__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8448);
/* harmony import */ var _disclosure_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5831);
/* harmony import */ var _disclosure_panel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4826);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_disclosure__WEBPACK_IMPORTED_MODULE_0__, _disclosure_button__WEBPACK_IMPORTED_MODULE_1__, _disclosure_panel__WEBPACK_IMPORTED_MODULE_2__]);
([_disclosure__WEBPACK_IMPORTED_MODULE_0__, _disclosure_button__WEBPACK_IMPORTED_MODULE_1__, _disclosure_panel__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7016:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Q": () => (/* reexport */ fence)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "prism-react-renderer"
var external_prism_react_renderer_ = __webpack_require__(7096);
var external_prism_react_renderer_default = /*#__PURE__*/__webpack_require__.n(external_prism_react_renderer_);
// EXTERNAL MODULE: external "react-use-clipboard"
var external_react_use_clipboard_ = __webpack_require__(4856);
var external_react_use_clipboard_default = /*#__PURE__*/__webpack_require__.n(external_react_use_clipboard_);
// EXTERNAL MODULE: external "parse-numeric-range"
var external_parse_numeric_range_ = __webpack_require__(861);
var external_parse_numeric_range_default = /*#__PURE__*/__webpack_require__.n(external_parse_numeric_range_);
;// CONCATENATED MODULE: ./src/components/fence/fence.utils.ts

function calculateLinesToHighlight(lines) {
    let LINE_REGEX = /{([\d,-]+)}/;
    if (LINE_REGEX.test(lines)) {
        const range = LINE_REGEX.exec(lines)[1];
        return (index)=>external_parse_numeric_range_default()(range).includes(index + 1);
    } else {
        return ()=>false;
    }
}

// EXTERNAL MODULE: external "@heroicons/react/24/outline"
var outline_ = __webpack_require__(2135);
;// CONCATENATED MODULE: ./src/components/fence/fence.tsx






/** NOTE:
 * https://github.com/markdoc/docs/blob/main/components/Code.js#L9
 */ //@ts-ignore
external_prism_react_renderer_.Prism.languages.markdoc = {
    tag: {
        pattern: /{%(.|\n)*?%}/i,
        inside: {
            tagType: {
                pattern: /^({%\s*\/?)(\w*|-)*\b/i,
                lookbehind: true
            },
            id: /#(\w|-)*\b/,
            string: /".*?"/,
            equals: /=/,
            number: /\b\d+\b/i,
            variable: {
                pattern: /\$[\w.]+/i,
                inside: {
                    punctuation: /\./i
                }
            },
            function: /\b\w+(?=\()/,
            punctuation: /({%|\/?%})/i,
            boolean: /false|true/
        }
    },
    variable: {
        pattern: /\$\w+/i
    },
    function: {
        pattern: /\b\w+(?=\()/i
    }
};
function Fence(props) {
    let { language , highlight , children: code  } = props;
    let [isCopied, setCopied] = external_react_use_clipboard_default()(code, {
        successDuration: 1000
    });
    let shouldHighlightLine = calculateLinesToHighlight(highlight);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        "aria-live": "polite",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((external_prism_react_renderer_default()), {
                ...external_prism_react_renderer_.defaultProps,
                Prism: external_prism_react_renderer_.Prism,
                language: language,
                code: code.trim(),
                children: ({ className , style , tokens , getLineProps , getTokenProps  })=>/*#__PURE__*/ jsx_runtime_.jsx("pre", {
                        className: className,
                        style: style,
                        children: tokens.map((line, index)=>{
                            const lineProps = getLineProps({
                                line,
                                key: index
                            });
                            if (shouldHighlightLine(index)) {
                                lineProps.className = `${lineProps.className} -mx-4 pl-3 pr-4 border-l-4 border-blue-600 bg-blue-300/10 dark:border-blue-600/80 dark:bg-gray-700/20`;
                            }
                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                ...lineProps,
                                children: line.map((token, key)=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        ...getTokenProps({
                                            token,
                                            key
                                        })
                                    }, key))
                            }, index);
                        })
                    })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: " absolute top-4 right-4 inline-flex items-center justify-center p-1 text-white bg-gray-600 rounded transition duration-100 ease-in appearance-none cursor-pointer select-none focus:outline-none hover:text-slate-200 hover:bg-gray-700 dark:bg-gray-600/20 dark:hover:bg-gray-700/10 ",
                onClick: setCopied,
                title: isCopied ? "copied" : "copy",
                children: isCopied ? /*#__PURE__*/ jsx_runtime_.jsx(outline_.CheckIcon, {
                    className: "h-4 w-4"
                }) : /*#__PURE__*/ jsx_runtime_.jsx(outline_.ClipboardIcon, {
                    className: "h-4 w-4"
                })
            })
        ]
    });
}
/* harmony default export */ const fence = (Fence);

;// CONCATENATED MODULE: ./src/components/fence/index.ts



/***/ }),

/***/ 1557:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OK": () => (/* reexport safe */ _tab__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "nP": () => (/* reexport safe */ _tab_panels__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "td": () => (/* reexport safe */ _tab_list__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "v0": () => (/* reexport safe */ _tab_group__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "x4": () => (/* reexport safe */ _tab_panel__WEBPACK_IMPORTED_MODULE_4__.Z)
/* harmony export */ });
/* harmony import */ var _tab_group__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(658);
/* harmony import */ var _tab_list__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1120);
/* harmony import */ var _tab__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8734);
/* harmony import */ var _tab_panels__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3704);
/* harmony import */ var _tab_panel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6381);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tab_group__WEBPACK_IMPORTED_MODULE_0__, _tab_list__WEBPACK_IMPORTED_MODULE_1__, _tab__WEBPACK_IMPORTED_MODULE_2__, _tab_panels__WEBPACK_IMPORTED_MODULE_3__, _tab_panel__WEBPACK_IMPORTED_MODULE_4__]);
([_tab_group__WEBPACK_IMPORTED_MODULE_0__, _tab_list__WEBPACK_IMPORTED_MODULE_1__, _tab__WEBPACK_IMPORTED_MODULE_2__, _tab_panels__WEBPACK_IMPORTED_MODULE_3__, _tab_panel__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 658:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function TabGroup(props) {
    let { children , ...rest } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full my-6",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Tab.Group, {
            ...rest,
            children: children
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabGroup);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1120:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function TabList(props) {
    let { children , ...rest } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Tab.List, {
        className: "p-2 bg-gray-50 dark:bg-gray-500/10 rounded-t-md",
        ...rest,
        children: children
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6381:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1185);
/* harmony import */ var _utils_classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8444);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_2__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function TabPanel(props) {
    let { children , ...rest } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Tab.Panel, {
        className: "bg-gray-100 dark:bg-gray-700/5 rounded-b-md text-sm focus:outline-none",
        ...rest,
        children: react__WEBPACK_IMPORTED_MODULE_1___default().Children.map(children, (child)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (0,_utils_classnames__WEBPACK_IMPORTED_MODULE_3__.cn)("[&>p]:m-0 [&>div>pre]:m-0 [&>div>pre]:rounded-t-none [&>div>pre]:dark:!bg-gray-700/5 [&>div>pre]:dark:border-t-0", //@ts-ignore
                Boolean(child?.props.language) ? "" : "p-4 "),
                children: child
            });
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabPanel);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3704:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
/* harmony import */ var _utils_classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8444);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function TabPanels(props) {
    let { children , ...rest } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Tab.Panels, {
        className: (0,_utils_classnames__WEBPACK_IMPORTED_MODULE_2__.cn)("rounded-b-md bg-gray-100"),
        ...rest,
        children: children
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabPanels);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8734:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
/* harmony import */ var _utils_classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8444);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function Tab(props) {
    let { label , children , disabled , ...rest } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Tab, {
        disabled: disabled,
        className: ({ selected  })=>(0,_utils_classnames__WEBPACK_IMPORTED_MODULE_2__.cn)("px-2 py-1.5 [&>p]:m-0", "text-sm tracking-tight font-mono transition-colors duration-150", "rounded-md select-none", "focus:outline-none", selected ? "text-slate-900 dark:text-white backdrop-blur bg-gray-200/50 dark:bg-gray-400/10" : "text-slate-400 hover:text-slate-900 dark:text-slate-500 dark:hover:text-slate-600", disabled && "text-slate-300 pointer-events-none"),
        ...rest,
        children: children ?? label
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Tab);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8444:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cn": () => (/* binding */ cn)
/* harmony export */ });
function cn(...classes) {
    return classes.filter(Boolean).join(" ");
}


/***/ })

};
;