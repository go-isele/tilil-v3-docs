"use strict";
exports.id = 805;
exports.ids = [805];
exports.modules = {

/***/ 8805:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _heroicons_react_20_solid_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1089);
/* harmony import */ var _heroicons_react_20_solid_index_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_20_solid_index_js__WEBPACK_IMPORTED_MODULE_2__);



function Burger() {
    const [active, setActive] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        const aside = document.querySelector("#aside");
        if (active) {
            aside?.classList.remove("hidden");
        } else {
            aside?.classList.add("hidden");
        }
    }, [
        active
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        id: "burger",
        type: "button",
        "aria-label": active ? "Close menu" : "Open menu",
        className: " lg:hidden inline-flex items-center justify-center p-1.5 mr-4 text-slate-600 border border-solid rounded-md bg-transparent transition duration-200 ease-in appearance-none select-none focus:ring-2 focus:ring-blue-600 focus:outline-none focus:bg-gray-100 dark:text-white dark:bg-gray-900 dark:border-gray-800 dark:focus-visible:border-blue-500 ",
        onClick: ()=>setActive((prev)=>!prev),
        children: active ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_20_solid_index_js__WEBPACK_IMPORTED_MODULE_2__.XMarkIcon, {
            className: "w-5 h-5"
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_20_solid_index_js__WEBPACK_IMPORTED_MODULE_2__.Bars3Icon, {
            className: "w-5 h-5"
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Burger);


/***/ })

};
;